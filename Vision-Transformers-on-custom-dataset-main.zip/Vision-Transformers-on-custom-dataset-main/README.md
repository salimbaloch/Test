### Image classification on custom dataset ( Google colab example)

![res](https://github.com/user-attachments/assets/0d71f29a-76a9-4581-9673-8380b57fcb03)
